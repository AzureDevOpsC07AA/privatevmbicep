﻿Set-ExecutionPolicy -Scope process -ExecutionPolicy Bypass
import-module .\RunWorkload.psm1
Invoke-SqlWorkload -SQLServer dp300khdls1we.database.windows.net -Database adventureworks2017 -UserName adminkhd -Password demo!pass123 -TSQLFile AdventureWorksWorkloadonlyselect.sql -Frequency 'Fast' 
