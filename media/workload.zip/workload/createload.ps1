﻿.\RunWorkload.ps1 -SQLServer dp300lsql1.database.windows.net -Database adventurework2017 -UserName adminkhd -Password demo!pass123 -TSQLFile C:\WorkLoad\AdventureWorksWorkload.sql -Frequency 'Fast'
