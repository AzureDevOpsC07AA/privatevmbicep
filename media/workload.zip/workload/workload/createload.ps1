﻿.\RunWorkload.ps1 -SQLServer lssqladv.database.windows.net -Database adventureworkslt -UserName adminkhd -Password demo!pass123 -TSQLFile C:\WorkLoad\AdventureWorksWorkload.sql -Frequency 'Fast'
